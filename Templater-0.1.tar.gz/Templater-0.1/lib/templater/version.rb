module Templater
  VERSION = '0.1'
end