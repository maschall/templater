module Templater
  VERSION = '0.2'
end